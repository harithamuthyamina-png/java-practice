package com.pack2;

import java.io.IOException;
import java.io.PrintWriter;


import javax.servlet.GenericServlet;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;

@WebServlet("/es")


public class EmployeeServlet extends GenericServlet
{
	public void service(ServletRequest req,ServletResponse res)throws ServletException,IOException
	{
		PrintWriter pw=res.getWriter();
		res.setContentType("text/html");
		String user_name=req.getParameter("ename");
		String user_id=req.getParameter("eid");
		String user_sal=req.getParameter("esal");
		String user_exp=req.getParameter("eexp");
//		double sal=Double.parseDouble(user_sal);
//		int exp=Integer.parseInt(user_exp);
//		
//       
		double sal = 0;
		int exp = 0;

		if (user_sal != null && !user_sal.isEmpty()) {
		    sal = Double.parseDouble(user_sal);
		}

		if (user_exp != null && !user_exp.isEmpty()) {
		    exp = Integer.parseInt(user_exp);
		}

    double revisedSal=sal;
		if(exp>=5) {
	    	   revisedSal=sal+(sal * 0.01);
      }	       
		pw.println("<center><h1>");
		pw.println("<u>****Employee Details*******</u><br><br>");
		pw.println("EmpName:"+user_name+"<br><br>");
		pw.println("EmpId:"+user_id+"<br><br>");
		pw.println("EmpSal:"+revisedSal+"<br><br>");
		pw.println("EmpExp:"+user_exp+"<br><br>");
		
		pw.println("</h1></center>");
	}
}
